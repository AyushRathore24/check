# Change Log

## [1.2.0] 2021-01-05
### Updates
- update to Angular 11
- update all dependencies to match Angular 11 version

## [1.1.0] 2020-03-11
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version

## [1.0.0] 2019-09-26
### Original Release
- Added Angular as base framework
- Added design from BLK Design System by Creative Tim
